<template>
  <div
    v-if="!multiple"
    class="update-image"
    :style="{
      'background-image': `url(${getUrl(modelValue)})`,
    }"
  >
    <span class="update" @click="openChooseImg">
      <el-icon>
        <edit />
      </el-icon>
      重新上传</span>
  </div>
  <div v-else class="multiple-img">
    <div
      v-for="(item, index) in multipleValue"
      :key="index"
      class="update-image"
      :style="{
        'background-image': `url(${getUrl(item)})`,
      }"
    >
      <span class="update" @click="deleteImg(index)">
        <el-icon>
          <delete />
        </el-icon>
        删除图片</span>
    </div>
    <div class="add-image">
      <span class="update" @click="openChooseImg">
        <el-icon>
          <folder-add />
        </el-icon>
        上传图片</span>
    </div>
  </div>

  <el-drawer v-model="drawer" title="媒体库" size="650px">
    <warning-bar
      title="点击“文件名/备注”可以编辑文件名或者备注内容。"
    />
    <div class="gva-btn-list">
      <upload-common
        v-model:imageCommon="imageCommon"
        class="upload-btn-media-library"
        @on-success="getImageList"
      />
      <upload-image
        v-model:imageUrl="imageUrl"
        :file-size="512"
        :max-w-h="1080"
        class="upload-btn-media-library"
        @on-success="getImageList"
      />
      <el-form ref="searchForm" :inline="true" :model="search">
        <el-form-item label="">
          <el-input v-model="search.keyword" class="keyword" placeholder="请输入文件名或备注" />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" icon="search" @click="getImageList">查询</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="media">
      <div v-for="(item,key) in picList" :key="key" class="media-box">
        <div class="header-img-box-list">
          <el-image
            :key="key"
            :src="getUrl(item.url)"
            @click="chooseImg(item.url)"
          >
            <template #error>
              <div class="header-img-box-list">
                <el-icon>
                  <picture />
                </el-icon>
              </div>
            </template>
          </el-image>
        </div>
        <div class="img-title" @click="editFileNameFunc(item)">{{ item.name }}</div>
      </div>
    </div>
    <el-pagination
      :current-page="page"
      :page-size="pageSize"
      :total="total"
      :style="{'justify-content':'center'}"
      layout="total, prev, pager, next, jumper"
      @current-change="handleCurrentChange"
      @size-change="handleSizeChange"
    />
  </el-drawer>
</template>

<script setup>

import { getUrl } from '@/utils/image'
import { onMounted, ref } from 'vue'
import { getFileList, editFileName } from '@/api/fileUploadAndDownload'
import UploadImage from '@/components/upload/image.vue'
import UploadCommon from '@/components/upload/common.vue'
import WarningBar from '@/components/warningBar/warningBar.vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Delete, FolderAdd } from '@element-plus/icons-vue'

const imageUrl = ref('')
const imageCommon = ref('')

const search = ref({})
const page = ref(1)
const total = ref(0)
const pageSize = ref(20)

const props = defineProps({
  modelValue: {
    type: [String, Array],
    default: ''
  },
  multiple: {
    type: Boolean,
    default: false
  }
})

const multipleValue = ref([])

onMounted(() => {
  if (props.multiple) {
    multipleValue.value = props.modelValue
  }
})

const emits = defineEmits(['update:modelValue'])

const deleteImg = (index) => {
  multipleValue.value.splice(index, 1)
  emits('update:modelValue', multipleValue.value)
}

// 分页
const handleSizeChange = (val) => {
  pageSize.value = val
  getImageList()
}

const handleCurrentChange = (val) => {
  page.value = val
  getImageList()
}
const editFileNameFunc = async(row) => {
  ElMessageBox.prompt('请输入文件名或者备注', '编辑', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    inputPattern: /\S/,
    inputErrorMessage: '不能为空',
    inputValue: row.name
  }).then(async({ value }) => {
    row.name = value
    // console.log(row)
    const res = await editFileName(row)
    if (res.code === 0) {
      ElMessage({
        type: 'success',
        message: '编辑成功!',
      })
      getImageList()
    }
  }).catch(() => {
    ElMessage({
      type: 'info',
      message: '取消修改'
    })
  })
}

const drawer = ref(false)
const picList = ref([])

const chooseImg = (url) => {
  if (props.multiple) {
    multipleValue.value.push(url)
    emits('update:modelValue', multipleValue.value)
  } else {
    emits('update:modelValue', url)
  }
  drawer.value = false
}
const openChooseImg = async() => {
  await getImageList()
  drawer.value = true
}

const getImageList = async() => {
  const res = await getFileList({ page: page.value, pageSize: pageSize.value, ...search.value })
  if (res.code === 0) {
    picList.value = res.data.list
    total.value = res.data.total
    page.value = res.data.page
    pageSize.value = res.data.pageSize
  }
}

</script>

<style scoped lang="scss">

.multiple-img{
  display: flex;
  gap:8px;
}

.add-image{
  width: 120px;
  height: 120px;
  line-height: 120px;
  display: flex;
  justify-content: center;
  border-radius: 20px;
  border: 1px dashed #ccc;
  background-size: cover;
  cursor: pointer;
}

.update-image {
  cursor: pointer;
  width: 120px;
  height: 120px;
  line-height: 120px;
  display: flex;
  justify-content: center;
  border-radius: 20px;
  border: 1px dashed #ccc;
   background-repeat: no-repeat;
   background-size: cover;
  &:hover {
    color: #fff;
    background: linear-gradient(
            to bottom,
            rgba(255, 255, 255, 0.15) 0%,
            rgba(0, 0, 0, 0.15) 100%
    ),
    radial-gradient(
            at top center,
            rgba(255, 255, 255, 0.4) 0%,
            rgba(0, 0, 0, 0.4) 120%
    )
    #989898;
    background-blend-mode: multiply, multiply;
    background-size: cover;
    .update {
      color: #fff;
    }
  }
  .update {
    height: 120px;
    width: 120px;
    text-align: center;
    color: transparent;
  }
}

.upload-btn-media-library {
  margin-left: 20px;
}

.media {
  display: flex;
  flex-wrap: wrap;

  .media-box {
    width: 120px;
    margin-left: 20px;

    .img-title {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      line-height: 36px;
      text-align: center;
      cursor: pointer;
    }

    .header-img-box-list {
      width: 120px;
      height: 120px;
      border: 1px dashed #ccc;
      border-radius: 8px;
      text-align: center;
      line-height: 120px;
      cursor: pointer;
      overflow: hidden;
      .el-image__inner {
        max-width: 120px;
        max-height: 120px;
        vertical-align: middle;
        width: unset;
        height: unset;
      }
    }
  }
}
</style>
