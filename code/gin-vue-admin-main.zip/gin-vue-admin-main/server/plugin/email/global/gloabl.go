package global

import "github.com/flipped-aurora/gin-vue-admin/server/plugin/email/config"

var GlobalConfig = new(config.Email)
