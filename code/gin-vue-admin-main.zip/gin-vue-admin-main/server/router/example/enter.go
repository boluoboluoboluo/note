package example

type RouterGroup struct {
	CustomerRouter
	FileUploadAndDownloadRouter
}
