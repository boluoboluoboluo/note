<template>
  <div class="load-end"> --------- 我也是有底线的啦 --------- </div>
</template>
<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "LoadEnd",
});
</script>
<style scoped>
.load-end {
  text-align: center;
  padding: 30px;
}
</style>

