
import app from '../main.js'  

class webviewUtil {

	/**向手机内存存数据
	 * @param {Object} type //手机系统类型
	 * @param {Object} key //数据键
	 * @param {Object} data  //数据
	 */
	static setData(type, key, data) {
		if ("other" == type) {
			uni.setStorageSync(key, data);
		} else if ("android" == type) {
			window.android_sys.putSpUtil(key, data);
		} else if ("ios" == type) {
			uni.setStorageSync(key, data);
		}
	}
	/**
	 * 获取手机内存数据
	 * @param {Object} type //系统类型
	 * @param {Object} key  //数据键
	 */
	static getData(type, key) {
		if ("other" == type) {
			return uni.getStorageSync(key);
		} else if ("android" == type) {
			return window.android_sys.getSpUtil(key);
		} else if ("ios" == type) {
			return uni.getStorageSync(key);
		}
	}
	/**
	 * 删除数据
	 * @param {Object} type 系统类型
	 * @param {Object} key  数据键
	 */
	static delData(type, key) {
		if ("other" == type) {
			return uni.removeStorageSync(key);
		} else if ("android" == type) {
			return window.android_sys.removeSpUtil(key);
		} else if ("ios" == type) {
			console.log(key)
			return uni.removeStorageSync(key);
		}
	}
	
}
export {
	webviewUtil
	
}
