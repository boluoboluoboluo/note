const _Request = uni.request
// const _apiDomain = 'https://smart-talent-tourshop-uat.ctf.com.cn';
const _apiDomain = '';//打包h5设为空值
// const _apiDomain = 'http://120.25.217.235:19999';
function config(options) {
	const {
		type,
		url,
		data
	} = options
	
	return new Promise((resolve, reject) => {
		_Request({
			url: url,
			method: type,
			data: data,
			header: {
				"Content-Type": 'application/json',
				"token": options.data.token
			},
			timeout: 60000,
			dataType: 'json',
			success: (res) => {
				resolve(res)
			},
			fail: (rej) => {
				reject(rej)
			}
		})
	})
}

function post(url, data = {}) {
	return config({
		type: 'POST',
		url: url,
		data: data,
		timeout: 60000,
		dataType: 'json'
	})
}




function put(url, data = {}) {
	return config({
		type: 'PUT',
		url: url,
		data: data,
		timeout: 60000,
		dataType: 'json'
	})
}


function get(url, data = {}) {
	return config({
		type: 'GET',
		url: url,
		data: data,
		timeout: 60000,
		dataType: 'json'
	})
}


function getBaseUrl() {
  // #ifdef H5
  return '/shoptour/app-api';
  // #endif
  // #ifdef APP-PLUS
  return _apiDomain;
  // #endif
}

function getBaseUrlA() {
  // #ifdef H5
  return '/shoptour';
  // #endif
  // #ifdef APP-PLUS
  return _apiDomain;
  // #endif
}


function getBaseUrlB() {
  // #ifdef H5
  return '/app-api';
  // #endif
  // #ifdef APP-PLUS
  return _apiDomain;
  // #endif
}



const API = {
	get,
	post,
	put,
	getBaseUrl,
	getBaseUrlA,
	getBaseUrlB

};



export default API

// * 清楚uni原生请求

// uni.request = () => {
// 	throw '\n错误: 请不要使用 uniapp 自带的 uni.request 方法,\n请使用 API.get 或者 API.post 代替';
// }
