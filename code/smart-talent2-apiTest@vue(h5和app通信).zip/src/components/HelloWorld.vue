<template>
  <div class="hello">

    <button @click="setconfig">设置验签信息</button>
    <button @click="getuser">获取当前用户(需先设置验签信息)</button>
    <button @click="buletooth">获取蓝牙</button>
    <button @click="location">获取定位</button>
    <button @click="scan">扫码</button>
    <button @click="chooseImage">图像与文件接口</button>
    <button @click="scanfromImage">识别图片二维码&条形码</button>
    <button @click="closeWebview">关闭当前页面</button>
    <button @click="getVersion">获取当前设备信息</button>
    <p> {{ msg }}</p>
  </div>
</template>

<script>
import { timestamp, nonceStr, sha256_digest, hex_md5 } from '../../utils/utils.js';

// const talent2AppId = "pSrX3CWN";
// const talent2Secretkey = "20d684c010c0cd7e1d9defd4826b86c3027baf49";

const talent2AppId = "u8gYG6ts";
const talent2Secretkey = "0f34c1d7e6ab5480c363d71ef895eb09d84861de";


export default {

  name: 'HelloSmartTalent2',
  data() {
    return {
      msg: 'SmartTalent2-API-Test'
    }
  },
  created() {
    window.Verification = this.setConfigCallback
    window.getUserInfo = this.getuserCallback
    window.iBeacon = this.bluetoothCallback
    window.getnow = this.locationCallback
    window.scanCode = this.scanCallback
    window.chooseImage = this.chooseImageCallback
    window.scanFromImg = this.scanfromImageCallback
    window.getVersion = this.getVersionCallBack
  },
  methods: {
    setconfig() {
      const _appId = talent2AppId
      const _secretkey = talent2Secretkey
      //生成签名的时间戳  
      //调用js里的方法timestamp() 
      const _timestamp = timestamp()
      //生成签名的随机串 
      //调用js里的方法  nonceStr()  生成随机串
      const _nonceStr = nonceStr()
      //获取当前页url  
      //调用js里的方法  getCurrentUrl()  生成随机串
      const _url = 'localhost'
      //字符拼接先后顺序,用于加密
      const splicingStr = `${_appId}${_secretkey}${_timestamp}${_nonceStr}${_url}`
      //字符加密方法 
      //调用js里的方法 sha256_digest(str)   hex_md5(str)
      const _signature = sha256_digest(splicingStr + hex_md5(splicingStr))

      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'Verification',
          params: {
            appId: _appId,
            timestamp: _timestamp,
            nonceStr: _nonceStr,
            signature: _signature,
            url: _url
          }
        }
      })
    },
    getuser() {
      let _sigin = localStorage.getItem('sigin');
      //向uniapp底座发送消息
      let time = parseInt(new Date().getTime() / 1000) + '';
      window.uni.postMessage({
        data: {
          api: 'getUserInfo',
          params: {
            appId: talent2AppId,
            sigin: _sigin,
            url: 'localhost',
            timestamp: time
          }
        }
      })
    },
    buletooth() {
      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'iBeacon',
          params: {
            uuids: ['800DB72B-5C3C-480B-B6F2-E7D5A7388E75']
          }
        }
      })
    },
    location() {
      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'getnow',
          params: {}
        }
      })
    },
    scan() {
      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'scanCode',
          params: {
            //0-- 允许从相机和相册扫码
            //2-- 只允许通过相机扫码
            //3-- 调起条码扫描
            type: 0
          }
        }
      })
    },
    chooseImage() {
      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'chooseImage',
          params: {}
        }
      })
    },
    scanfromImage() {
      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'scanFromImg',
          params: {
            //0-- 允许从相机和相册扫码
            //1-- 只允许通过相机扫码
            //2-- 只允许相册
            type: 2
          }
        }
      })
    },
    closeWebview(){
      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'closeCurrentView',
          params: {}
        }
      })
    },
    getVersion(){
      // 向uniapp底座发送消息
      window.uni.postMessage({
        data: {
          api: 'getVersion',
          params: {}
        }
      })
    },
    setConfigCallback(_res) {
      let msg = {};
      let res = _res.data.data.sigin;
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 1, data: res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    getuserCallback(_res) {
      console.log('接收2.0app回调========' + JSON.stringify(_res))
      let msg = {};
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 2, data: _res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    bluetoothCallback(_res) {
      let msg = {};
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 3, data: _res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    locationCallback(_res) {
      let msg = {};
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 4, data: _res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    scanCallback(_res) {
      let msg = {};
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 5, data: _res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    chooseImageCallback(_res) {
      let msg = {};
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 6, data: _res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    scanfromImageCallback(_res) {
      let msg = {};
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 7, data: _res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    getVersionCallBack(_res) {
      let msg = {};
      if (_res != "" || _res != null || _res != undefined) {
        msg = { code: 8, data: _res, message: "" }
      } else {
        msg = { code: -1, data: "", message: "无回调内容" }
      }
      this.getCallBack(msg);
    },
    getCallBack(_msg) {
      console.log('接收2.0app回调========' + JSON.stringify(_msg))
      switch (_msg.code) {
        case 1:  //config回调
          //调用getUserInfo需用此sigin
          localStorage.setItem('sigin', _msg.data);
          alert("sigin:" + _msg.data);
          return;
        case 2: //获取用户信息回调
          //如果开启了sso就解析idToken
          this.msg = JSON.stringify(_msg.data.data);
          if (_msg.data.data.data.sso == 1) {
            console.log("当前登录用户信息:" + JSON.stringify(_msg.data.data.data));
            console.log("当前登录用户idToken:" + _msg.data.data.data.userId);
            alert("当前登录用户idToken:" + _msg.data.data.data.userId);
          } else {
            console.log("当前登录用户id:" + _msg.data.data.data.userId);
            alert("当前登录用户id:" + _msg.data.data.data.userId);
          }
          return;
        case 3://蓝牙
          console.log("蓝牙信息:" + JSON.stringify(_msg));
          alert("蓝牙信息:" + JSON.stringify(_msg));
          return;
        case 4://定位
          console.log("定位信息:" + JSON.stringify(_msg));
          alert("定位信息:" + JSON.stringify(_msg));
          return;
        case 5: //扫码
          console.log("扫码信息:" + JSON.stringify(_msg));
          alert("扫码信息:" + JSON.stringify(_msg));
          return;
        case 6: //图像与文件接口
          console.log("图片信息:" + JSON.stringify(_msg));
          alert("图片信息:" + JSON.stringify(_msg));
          return;
        case 7: //图片识别码
          console.log("识别信息:" + JSON.stringify(_msg));
          alert("识别信息:" + JSON.stringify(_msg));
          return;
        case 8: //当前设备信息
          console.log("设备信息:" + JSON.stringify(_msg));
          alert("设备信息:" + JSON.stringify(_msg));
          return;
        case -1://无返回
          return;
      }
    }
  }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.hello {
  background-color: antiquewhite;
}

h1,
h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
